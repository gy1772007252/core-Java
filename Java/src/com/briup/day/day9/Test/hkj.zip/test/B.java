package Test.test;

public class B extends A {
    public B() {
        System.out.println("B");
    }
}
