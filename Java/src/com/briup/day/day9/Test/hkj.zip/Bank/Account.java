package Test.Bank;

public class Account {

    double balance;

    public Account(double balance) {
        this.balance = balance;
    }
    public boolean deposit(double amount) {
        this.balance += amount;
        return true;
    }
    public boolean withdraw(double amount) {
        if (this.balance - amount >= 0) {
            this.balance -= amount;
            return true;
        }
        else
            return false;
    }
    public double getBalance() {
        return balance;
    }

}
