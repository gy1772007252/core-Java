package Test.test;

public class Test {
    public static void main(String[] args) {
        new B();
        System.out.println("-------");
        new A();
    }
}
