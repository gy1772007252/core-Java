package Test.Vehicle;

public class Vehicle {

    String brand, number;
    public double getsumrent(int days) {
        return 0.0;
    }

}
