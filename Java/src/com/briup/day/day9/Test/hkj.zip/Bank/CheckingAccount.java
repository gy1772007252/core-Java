package Test.Bank;

public class CheckingAccount extends Account{

    double overdraft;

    public CheckingAccount(double balance, double overdraft) {
        super(balance);
        this.overdraft = overdraft;
    }
    public CheckingAccount(double balance) {
        super(balance);
    }
    public boolean withdraw(double amount) {
        if (this.balance - amount >= 0) {
            this.balance -= amount;
            return true;
        } else if (this.balance + overdraft >= amount) {
            if (this.balance == 0){
                this.overdraft -= amount;
                return true;
            } else {
                amount -= this.balance;
                this.balance = 0;
                this.overdraft -= amount;
                return true;
            }
        } else return false;
    }
    public double getOverdraft() {
        return overdraft;
    }

}
